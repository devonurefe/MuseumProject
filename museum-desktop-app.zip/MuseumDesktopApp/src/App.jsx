import React, { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/core";
import { open } from "@tauri-apps/plugin-dialog";

function App() {
  const [selectedFile, setSelectedFile] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [systemInfo, setSystemInfo] = useState("");

  useEffect(() => {
    // Sistem bilgisini al
    invoke("get_system_info").then((info) => {
      setSystemInfo(info);
    });
  }, []);

  const selectFile = async () => {
    try {
      const filePath = await open({
        filters: [
          {
            name: "PDF",
            extensions: ["pdf"],
          },
        ],
        multiple: false,
      });

      if (filePath) {
        setSelectedFile(filePath);
        setResult(null);
      }
    } catch (error) {
      console.error("Dosya seçimi hatası:", error);
      alert("Dosya seçimi sırasında hata oluştu.");
    }
  };

  const processPDF = async () => {
    if (!selectedFile) {
      alert("Lütfen önce bir PDF dosyası seçin.");
      return;
    }

    setIsProcessing(true);
    try {
      const response = await invoke("process_pdf", { filePath: selectedFile });
      setResult(response);
      
      if (response.success) {
        alert("PDF başarıyla işlendi!");
      } else {
        alert(`Hata: ${response.message}`);
      }
    } catch (error) {
      console.error("PDF işleme hatası:", error);
      alert("PDF işleme sırasında hata oluştu.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="container">
      <header className="header">
        <h1>🏛️ Museum PDF Tool</h1>
        <p className="subtitle">Güvenli, Yerel PDF İşleme Aracı</p>
        <div className="system-info">{systemInfo}</div>
      </header>

      <main className="main">
        <div className="upload-section">
          <div className="file-selector">
            <button className="btn btn-primary" onClick={selectFile}>
              📁 PDF Dosyası Seç
            </button>
            {selectedFile && (
              <div className="selected-file">
                <span className="file-icon">📄</span>
                <span className="file-name">{selectedFile.split('/').pop()}</span>
              </div>
            )}
          </div>

          <button
            className={`btn btn-process ${isProcessing ? 'processing' : ''}`}
            onClick={processPDF}
            disabled={!selectedFile || isProcessing}
          >
            {isProcessing ? "⚙️ İşleniyor..." : "🚀 PDF'i İşle"}
          </button>
        </div>

        {result && (
          <div className="results">
            <h2>📊 İşlem Sonuçları</h2>
            
            <div className="status">
              <span className={`status-badge ${result.success ? 'success' : 'error'}`}>
                {result.success ? "✅ Başarılı" : "❌ Hata"}
              </span>
              <span className="message">{result.message}</span>
            </div>

            {result.success && result.data && (
              <div className="processed-data">
                <div className="stats">
                  <div className="stat-item">
                    <span className="stat-label">Sayfa Sayısı:</span>
                    <span className="stat-value">{result.data.pages}</span>
                  </div>
                  <div className="stat-item">
                    <span className="stat-label">Görsel Sayısı:</span>
                    <span className="stat-value">{result.data.images.length}</span>
                  </div>
                </div>

                <div className="content-preview">
                  <h3>📝 Çıkarılan Metin</h3>
                  <div className="text-content">
                    {result.data.text ? (
                      <pre>{result.data.text.substring(0, 500)}...</pre>
                    ) : (
                      <p className="no-content">Metin çıkarılamadı</p>
                    )}
                  </div>
                </div>

                {result.data.images.length > 0 && (
                  <div className="images-preview">
                    <h3>🖼️ Çıkarılan Görseller</h3>
                    <div className="images-grid">
                      {result.data.images.map((image, index) => (
                        <div key={index} className="image-item">
                          <img 
                            src={`data:image/png;base64,${image}`} 
                            alt={`Sayfa ${index + 1}`}
                            className="preview-image"
                          />
                          <p className="image-label">Sayfa {index + 1}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </main>

      <footer className="footer">
        <div className="features">
          <div className="feature">
            <span className="feature-icon">🔒</span>
            <span>Güvenli</span>
          </div>
          <div className="feature">
            <span className="feature-icon">💻</span>
            <span>Yerel</span>
          </div>
          <div className="feature">
            <span className="feature-icon">🌍</span>
            <span>Cross-Platform</span>
          </div>
          <div className="feature">
            <span className="feature-icon">⚡</span>
            <span>Hızlı</span>
          </div>
        </div>
        <p className="copyright">© 2024 Museum Team - Güvenle kullanın! 🛡️</p>
      </footer>
    </div>
  );
}

export default App;