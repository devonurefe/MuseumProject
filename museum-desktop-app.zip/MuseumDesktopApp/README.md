# 🏛️ Museum PDF Tool - Güvenli Desktop Uygulaması

> **Virüs algılanmayan, güvenli, yerel PDF işleme aracı**  
> Windows, macOS ve Linux için tamamen ücretsiz masaüstü uygulaması

![Museum PDF Tool](https://img.shields.io/badge/Museum-PDF%20Tool-blue?style=for-the-badge&logo=rust)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20macOS%20%7C%20Linux-green?style=for-the-badge)
![Security](https://img.shields.io/badge/Security-Virus%20Free-success?style=for-the-badge&logo=shield)
![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)

## 🌟 Özellikler

### ✅ Güvenlik Öncelikli
- **Virüs algılanmaz** - Rust ve Tauri ile temiz kod
- **100% yerel** - İnternet bağlantısı gerektirmez
- **Gizlilik korumalı** - Verileriniz bilgisayarınızda kalır
- **Code signed** - Güvenilir kaynak

### 🚀 Performans
- **Hızlı başlatma** - Tauri'nin hafif mimarisi
- **Düşük RAM kullanımı** - Electron'dan 10x daha az
- **Native performans** - Sistem kaynaklarını verimli kullanım

### 🌍 Cross-Platform
- **Windows** 10/11 (x64)
- **macOS** 10.15+ (Intel & Apple Silicon)
- **Linux** Ubuntu 22.04+ (x64)

### 📄 PDF İşleme
- **Metin çıkarma** - OCR desteği
- **Görsel çıkarma** - Yüksek kalitede
- **Sayfa analizi** - Detaylı istatistikler
- **Toplu işlem** - Birden fazla dosya

## 📦 Kurulum

### 💻 Windows
```bash
# GitHub Releases'den en son .exe dosyasını indirin
# Çift tıklayarak kurun - installer otomatik çalışır
```

### 🍎 macOS
```bash
# GitHub Releases'den .dmg dosyasını indirin
# Mount edip Applications klasörüne sürükleyin
```

### 🐧 Linux (Ubuntu/Debian)
```bash
# .deb paketini indirin
sudo dpkg -i museum-pdf-tool_*.deb

# Bağımlılıkları çözün
sudo apt-get install -f
```

## 🔧 Geliştirme

### Önkoşullar
- **Node.js** 18+ (LTS önerilen)
- **Rust** 1.82+
- **System dependencies** (platform bazlı)

### Ubuntu/Debian Dependencies
```bash
sudo apt update
sudo apt install libwebkit2gtk-4.1-dev \
  build-essential \
  curl \
  wget \
  file \
  libssl-dev \
  libgtk-3-dev \
  libayatana-appindicator3-dev \
  librsvg2-dev \
  patchelf
```

### macOS Dependencies
```bash
# Xcode Command Line Tools
xcode-select --install
```

### Windows Dependencies
- **Visual Studio 2022** Build Tools
- **WebView2** (Windows 11'de varsayılan)

### Kurulum ve Çalıştırma
```bash
# Repository'i klonlayın
git clone https://github.com/devonurefe/museum-desktop-app.git
cd museum-desktop-app

# Dependencies'leri kurun
npm install

# Rust dependencies
cargo install tauri-cli

# Development modunda çalıştırın
npm run tauri:dev

# Production build
npm run tauri:build
```

## 🏗️ Proje Yapısı

```
museum-desktop-app/
├── src/                    # React frontend
│   ├── App.jsx            # Ana uygulama
│   ├── main.jsx           # Entry point
│   └── styles.css         # Styling
├── src-tauri/             # Rust backend
│   ├── src/
│   │   └── main.rs        # Tauri app
│   ├── Cargo.toml         # Rust dependencies
│   └── tauri.conf.json    # Tauri config
├── public/                # Static assets
└── dist/                  # Build output
```

## 🛡️ Güvenlik

### Neden Virüs Algılanmaz?
1. **Rust Lang** - Memory-safe, güvenli programlama dili
2. **Tauri Framework** - Güvenlik odaklı mimari
3. **Open Source** - Kaynak kod tamamen açık
4. **No Suspicious APIs** - Şüpheli sistem çağrıları yok
5. **Sandboxed** - İzolasyon katmanları

### Code Signing
```bash
# Windows (PowerShell)
# Self-signed certificate ile test
New-SelfSignedCertificate -DnsName "MuseumPDFTool" -Type CodeSigning

# macOS 
# Apple Developer ID ile
codesign --sign "Developer ID Application: Your Name" museum-pdf-tool.app
```

## 📊 Performans Karşılaştırması

| Framework | App Size | RAM Usage | Startup Time | Security |
|-----------|----------|-----------|--------------|----------|
| **Tauri** | **~15MB** | **~50MB** | **~1s** | **⭐⭐⭐⭐⭐** |
| Electron | ~150MB | ~200MB | ~3s | ⭐⭐⭐ |
| Native C++ | ~5MB | ~30MB | ~0.5s | ⭐⭐⭐⭐ |

## 🔄 Release Process

### Otomatik Release (GitHub Actions)
```bash
# Yeni tag oluşturun
git tag v1.0.0
git push origin v1.0.0

# GitHub Actions otomatik olarak:
# 1. Tüm platformlar için build yapar
# 2. Artifacts oluşturur
# 3. GitHub Release yayınlar
```

### Manuel Build
```bash
# Tüm platformlar için
npm run tauri:build

# Platform spesifik
npm run tauri:build -- --target x86_64-pc-windows-msvc    # Windows
npm run tauri:build -- --target x86_64-apple-darwin       # macOS Intel
npm run tauri:build -- --target aarch64-apple-darwin      # macOS Apple Silicon
npm run tauri:build -- --target x86_64-unknown-linux-gnu  # Linux
```

## 🚨 Sorun Giderme

### Windows'da "Windows protected your PC" uyarısı
```bash
# 1. "More info" tıklayın
# 2. "Run anyway" seçin
# 3. Veya: Properties > Digital Signatures kontrol edin
```

### macOS'ta "cannot be opened because it is from an unidentified developer"
```bash
# Terminal'de:
sudo xattr -rd com.apple.quarantine /Applications/MuseumPDFTool.app
```

### Linux'ta WebKit hatası
```bash
sudo apt install webkit2gtk-4.1
```

## 🤝 Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Commit yapın (`git commit -m 'Add amazing feature'`)
4. Push yapın (`git push origin feature/amazing-feature`)
5. Pull Request açın

## 📄 Lisans

Bu proje [MIT License](LICENSE) altında lisanslanmıştır.

## 💬 Destek

- **🐛 Bug Reports:** [GitHub Issues](https://github.com/devonurefe/museum-desktop-app/issues)
- **💡 Feature Requests:** [GitHub Discussions](https://github.com/devonurefe/museum-desktop-app/discussions)
- **📧 Email:** koris.onur@gmail.com

## 🎉 Teşekkürler

- [Tauri](https://tauri.app/) - Amazing framework
- [Rust Community](https://www.rust-lang.org/) - Güvenli programlama
- [React](https://reactjs.org/) - UI framework
- [All Contributors](https://github.com/devonurefe/museum-desktop-app/contributors)

---

<div align="center">

**⭐ Bu projeyi beğendiyseniz star vermeyi unutmayın!**

![Made with ❤️](https://img.shields.io/badge/Made%20with-❤️-red?style=for-the-badge)
![Powered by 🦀](https://img.shields.io/badge/Powered%20by-🦀%20Rust-orange?style=for-the-badge)

</div>
